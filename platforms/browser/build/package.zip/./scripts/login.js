/**
 * Created by Kenneth on 02/08/2015.
 */
$(document).ready(function() {
    $("#btnlogin").click(function(){
        app.navi.pushPage('main.html');
    });
});